Real life twitter
==================

Uso
====
git clone https://github.com/Ibercivis/TwitterDataMining
python setup.py install
TwitterDataMiner --help

Dependencias
=============
python-twitter
python-mysqldb
bash >= 4
python 2.6 - 2.7 (no probado con otras versiones de python, puedes probar a utilizar 2to3 para python3)

Usage
======
git clone https://github.com/Ibercivis/TwitterDataMining
python setup.py install
TwitterDataMiner --help

Dependencias
=============
python-twitter
python-mysqldb
bash >= 4
python 2.6 - 2.7 (not tested with any other python version, you can try using 2to3 for python3 compat)
